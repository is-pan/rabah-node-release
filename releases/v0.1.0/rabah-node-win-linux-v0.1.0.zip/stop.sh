#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"

CONFIG_FILE="${SCRIPT_DIR}/node-config.txt"

NODE_NAME="${NODE_NAME:-}"
GPU_INDEX="${GPU_INDEX:-}"
STOP_ALL="${STOP_ALL:-0}"
NO_PAUSE="${NO_PAUSE:-}"

if [[ -f "${CONFIG_FILE}" ]]; then
  while IFS='=' read -r k v; do
    [[ -z "${k}" ]] && continue
    case "${k}" in
      GPU_INDEX) [[ -z "${GPU_INDEX}" ]] && GPU_INDEX="${v}" ;;
      NODE_NAME) [[ -z "${NODE_NAME}" ]] && NODE_NAME="${v}" ;;
    esac
  done < "${CONFIG_FILE}"
fi

if [[ -z "${NODE_NAME}" ]]; then
  if [[ -z "${GPU_INDEX}" ]]; then
    GPU_INDEX="0"
  fi
  NODE_NAME="rabah-node-gpu${GPU_INDEX}"
fi

docker --version >/dev/null 2>&1 || {
  echo "ERROR: Docker not found in PATH." >&2
  exit 1
}

docker info >/dev/null 2>&1 || {
  echo "ERROR: Docker is not running." >&2
  exit 1
}

stop_one() {
  local target="$1"
  [[ -z "${target}" ]] && return 0
  echo "- stopping ${target}"
  docker stop "${target}" >/dev/null 2>&1 || true
  docker rm "${target}" >/dev/null 2>&1 || true
}

mapfile -t CONTAINERS < <(docker ps --format "{{.Names}}" | grep -i -E '^rabah-node' || true)
COUNT="${#CONTAINERS[@]}"

if [[ "${STOP_ALL}" == "1" ]]; then
  if [[ "${COUNT}" == "0" ]]; then
    echo "No running node containers found by name prefix: rabah-node"
    exit 0
  fi
  echo "Stopping all running node containers with name prefix: rabah-node"
  for name in "${CONTAINERS[@]}"; do
    stop_one "${name}"
  done
  echo "Done."
  exit 0
fi

if [[ "${COUNT}" == "0" ]]; then
  echo "No running node containers found by name prefix: rabah-node"
  echo "Attempting to stop configured node: ${NODE_NAME}"
  stop_one "${NODE_NAME}"
  echo "Done."
  exit 0
fi

if [[ "${COUNT}" == "1" ]]; then
  echo "Stopping node container: ${CONTAINERS[0]}"
  stop_one "${CONTAINERS[0]}"
  echo "Done."
  exit 0
fi

echo "Found ${COUNT} node containers:"
for i in "${!CONTAINERS[@]}"; do
  idx="$((i + 1))"
  echo "  [${idx}] ${CONTAINERS[$i]}"
done
echo "  [A] Stop all"
echo "  [Q] Quit"
read -r -p "Select: " CHOICE

if [[ -z "${CHOICE}" ]]; then
  CHOICE="1"
fi

if [[ "${CHOICE,,}" == "q" ]]; then
  exit 0
fi

if [[ "${CHOICE,,}" == "a" ]]; then
  echo "Stopping all running node containers with name prefix: rabah-node"
  for name in "${CONTAINERS[@]}"; do
    stop_one "${name}"
  done
  echo "Done."
  exit 0
fi

if [[ ! "${CHOICE}" =~ ^[0-9]+$ ]]; then
  echo "ERROR: Invalid selection." >&2
  exit 1
fi

SELECTED_INDEX="$((CHOICE - 1))"
if (( SELECTED_INDEX < 0 || SELECTED_INDEX >= COUNT )); then
  echo "ERROR: Invalid selection." >&2
  exit 1
fi

SELECTED_NAME="${CONTAINERS[$SELECTED_INDEX]}"
echo "Stopping node container: ${SELECTED_NAME}"
stop_one "${SELECTED_NAME}"
echo "Done."
exit 0
