@echo off
setlocal EnableExtensions EnableDelayedExpansion

cd /d "%~dp0"

title Rabah Network Node

set "CONFIG_FILE=%~dp0node-config.txt"
set "WALLET_ADDRESS=%WALLET_ADDRESS%"
set "GPU_INDEX=%GPU_INDEX%"
set "NODE_NAME=%NODE_NAME%"
set "MODELS_DIR=%MODELS_DIR%"
set "RESET_CONFIG=%RESET_CONFIG%"
set "ASK_ON_START=%ASK_ON_START%"
set "DRY_RUN=%DRY_RUN%"
set "NO_PAUSE=%NO_PAUSE%"
set "AUTO_UPDATE=%AUTO_UPDATE%"
set "AGENT_IMAGE=%AGENT_IMAGE%"
set "ENV_FILE_ARG="
set "ENV_FILE_FOUND=0"
set "SERVER_URL_DISPLAY="
if exist "%~dp0.env" (
  set "ENV_FILE_FOUND=1"
  set "ENV_FILE_ARG=--env-file ""%~dp0.env"""
  for /f "usebackq tokens=1,* delims==" %%A in ("%~dp0.env") do (
    if /i "%%A"=="SERVER_URL" if "!SERVER_URL_DISPLAY!"=="" set "SERVER_URL_DISPLAY=%%B"
    if /i "%%A"=="AUTO_UPDATE" if "!AUTO_UPDATE!"=="" set "AUTO_UPDATE=%%B"
    if /i "%%A"=="AGENT_IMAGE" if "!AGENT_IMAGE!"=="" set "AGENT_IMAGE=%%B"
    if /i "%%A"=="MODELS_DIR" if "!MODELS_DIR!"=="" set "MODELS_DIR=%%B"
  )
)

docker --version >nul 2>nul
if errorlevel 1 (
  echo ERROR: Docker not found in PATH.
  echo Please install Docker Desktop and reopen this window.
  echo.
  pause
  exit /b 1
)

docker info >nul 2>nul
if errorlevel 1 (
  echo ERROR: Docker is not running.
  echo Please start Docker Desktop ^(Linux containers^) and try again.
  echo.
  pause
  exit /b 1
)

if /i "%RESET_CONFIG%"=="1" (
  if exist "%CONFIG_FILE%" del /f /q "%CONFIG_FILE%" >nul 2>nul
  set "NODE_NAME="
)

if exist "%CONFIG_FILE%" (
  for /f "usebackq tokens=1,* delims==" %%A in ("%CONFIG_FILE%") do (
    if /i "%%A"=="WALLET_ADDRESS" if "!WALLET_ADDRESS!"=="" set "WALLET_ADDRESS=%%B"
    if /i "%%A"=="GPU_INDEX" if "!GPU_INDEX!"=="" set "GPU_INDEX=%%B"
    if /i "%%A"=="NODE_NAME" if "!NODE_NAME!"=="" set "NODE_NAME=%%B"
    if /i "%%A"=="MODELS_DIR" if "!MODELS_DIR!"=="" set "MODELS_DIR=%%B"
  )
)

if "%AUTO_UPDATE%"=="" set "AUTO_UPDATE=1"
if "%AGENT_IMAGE%"=="" set "AGENT_IMAGE=ghcr.io/is-pan/rabah-node:latest"
if "%MODELS_DIR%"=="" set "MODELS_DIR=%~dp0models"

set "MODELS_DIR=!MODELS_DIR:"=!"
set "MODELS_DIR_IS_ABS=0"
if "!MODELS_DIR:~1,1!"==":" set "MODELS_DIR_IS_ABS=1"
if "!MODELS_DIR:~0,2!"=="\\" set "MODELS_DIR_IS_ABS=1"
if "!MODELS_DIR:~0,1!"=="/" set "MODELS_DIR_IS_ABS=1"
if "!MODELS_DIR_IS_ABS!"=="0" (
  for %%I in ("%~dp0!MODELS_DIR!") do set "MODELS_DIR=%%~fI"
) else (
  for %%I in ("!MODELS_DIR!") do set "MODELS_DIR=%%~fI"
)

if /i "%ASK_ON_START%"=="1" (
  set "ASK_WALLET=1"
  set "ASK_GPU=1"
) else (
  set "ASK_WALLET=0"
  set "ASK_GPU=0"
)

if "%WALLET_ADDRESS%"=="" set "ASK_WALLET=1"
if "%GPU_INDEX%"=="" set "ASK_GPU=1"

if "%ASK_WALLET%"=="1" (
  echo First time setup:
  echo - Please enter your wallet address ^(same as the one bound in the web Settings page^).
  if not "!WALLET_ADDRESS!"=="" (
    echo Current wallet: !WALLET_ADDRESS!
  )
  set /p WALLET_ADDRESS=Wallet Address: 
  if "!WALLET_ADDRESS!"=="" (
    echo ERROR: Wallet Address is required.
    echo.
    pause
    exit /b 1
  )
)

if "%ASK_GPU%"=="1" (
  echo.
  echo GPU selection:
  echo - Enter GPU index ^(default 0^). If you have only one GPU, use 0.
  if not "!GPU_INDEX!"=="" (
    echo Current GPU_INDEX: !GPU_INDEX!
  )
  set /p GPU_INDEX=GPU_INDEX [0]: 
  if "!GPU_INDEX!"=="" set "GPU_INDEX=0"
)

if "%NODE_NAME%"=="" (
  set "NODE_NAME=rabah-node-gpu%GPU_INDEX%"
) else (
  if /i "%NODE_NAME%"=="rabah-node" set "NODE_NAME=rabah-node-gpu%GPU_INDEX%"
)

if /i "%DRY_RUN%"=="1" (
  set "SKIP_SAVE_CONFIG=1"
) else (
  set "SKIP_SAVE_CONFIG=0"
)

if /i "%SKIP_SAVE_CONFIG%"=="0" (
  (
    echo WALLET_ADDRESS=%WALLET_ADDRESS%
    echo GPU_INDEX=%GPU_INDEX%
    echo NODE_NAME=%NODE_NAME%
    echo MODELS_DIR=%MODELS_DIR%
  ) > "%CONFIG_FILE%"
)

if not exist "%MODELS_DIR%" mkdir "%MODELS_DIR%"
if not exist "%~dp0outputs" mkdir "%~dp0outputs"
if not exist "%~dp0custom_nodes" mkdir "%~dp0custom_nodes"
if not exist "%~dp0workflows" mkdir "%~dp0workflows"

echo.
echo Starting node agent...
if "%SERVER_URL_DISPLAY%"=="" (
  if "%ENV_FILE_FOUND%"=="1" (
    echo - SERVER_URL: default ^(not set in .env^)
  ) else (
    echo - SERVER_URL: default ^(built-in^)
  )
) else (
  echo - SERVER_URL: %SERVER_URL_DISPLAY%
)
echo - WALLET_ADDRESS: %WALLET_ADDRESS%
echo - GPU_INDEX: %GPU_INDEX%
echo - NODE_NAME: %NODE_NAME%
echo.

if /i "%AUTO_UPDATE%"=="1" (
  if /i "%AGENT_IMAGE%"=="rabah-agent:local" (
    where git >nul 2>nul
    if not errorlevel 1 (
      if exist "%~dp0.git" (
        echo Updating agent source via git pull...
        git -C "%~dp0" pull --rebase --autostash
      )
    )
  ) else (
    echo Pulling latest image: %AGENT_IMAGE%
    docker pull "%AGENT_IMAGE%"
  )
)

if /i "%AGENT_IMAGE%"=="rabah-agent:local" (
  docker image inspect rabah-agent:local >nul 2>nul
  if errorlevel 1 (
    echo Building local image: rabah-agent:local
    docker build -t rabah-agent:local "%~dp0"
    if errorlevel 1 (
      echo.
      echo ERROR: Failed to build image rabah-agent:local
      echo.
      pause
      exit /b 1
    )
  )
  set "DOCKER_CMD=docker run --rm --name ""%NODE_NAME%"" --gpus all %ENV_FILE_ARG% -w /workspace -e ""WALLET_ADDRESS=%WALLET_ADDRESS%"" -e ""GPU_INDEX=%GPU_INDEX%"" -e ""NODE_NAME=%NODE_NAME%"" -e ""CUDA_DEVICE_ORDER=PCI_BUS_ID"" -e ""CUDA_VISIBLE_DEVICES=%GPU_INDEX%"" -e ""NVIDIA_VISIBLE_DEVICES=%GPU_INDEX%"" -e ""PYTHONUNBUFFERED=1"" -e ""PYTHONPATH=/workspace:/app"" -e ""COMFYUI_WORKFLOWS_DIR=/workspace/workflows"" -v ""%~dp0.:/workspace"" -v ""%MODELS_DIR%:/app/models"" -v ""%MODELS_DIR%:/app/ComfyUI/models"" -v ""%~dp0outputs:/app/outputs"" -v ""%~dp0custom_nodes:/app/ComfyUI/custom_nodes"" rabah-agent:local python -u /workspace/comfy_agent.py"
) else (
  set "DOCKER_CMD=docker run --rm --name ""%NODE_NAME%"" --gpus all %ENV_FILE_ARG% -e ""WALLET_ADDRESS=%WALLET_ADDRESS%"" -e ""GPU_INDEX=%GPU_INDEX%"" -e ""NODE_NAME=%NODE_NAME%"" -e ""CUDA_DEVICE_ORDER=PCI_BUS_ID"" -e ""CUDA_VISIBLE_DEVICES=%GPU_INDEX%"" -e ""NVIDIA_VISIBLE_DEVICES=%GPU_INDEX%"" -e ""PYTHONUNBUFFERED=1"" -v ""%MODELS_DIR%:/app/models"" -v ""%MODELS_DIR%:/app/ComfyUI/models"" -v ""%~dp0outputs:/app/outputs"" -v ""%~dp0custom_nodes:/app/ComfyUI/custom_nodes"" %AGENT_IMAGE%"
)

if /i "%DRY_RUN%"=="1" (
  echo DRY_RUN=1
  echo %DOCKER_CMD%
  echo.
  if /i "%NO_PAUSE%"=="1" exit /b 0
  pause
  exit /b 0
)

docker rm -f "%NODE_NAME%" >nul 2>nul

%DOCKER_CMD%

set "EXIT_CODE=%errorlevel%"
if not "%EXIT_CODE%"=="0" (
  echo.
  echo Node exited with code %EXIT_CODE%.
  echo If the window closes too fast on double-click, run it from cmd to see logs:
  echo   cd /d "%~dp0"
  echo   start.bat
  echo.
  pause
  exit /b %EXIT_CODE%
)

endlocal
