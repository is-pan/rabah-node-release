#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"

CONFIG_FILE="${SCRIPT_DIR}/node-config.txt"

NODE_NAME="${NODE_NAME:-}"
GPU_INDEX="${GPU_INDEX:-}"
WALLET_ADDRESS="${WALLET_ADDRESS:-}"
MODELS_DIR="${MODELS_DIR:-}"
AGENT_IMAGE="${AGENT_IMAGE:-}"
AUTO_UPDATE="${AUTO_UPDATE:-}"
RESET_CONFIG="${RESET_CONFIG:-}"
ASK_ON_START="${ASK_ON_START:-}"
DRY_RUN="${DRY_RUN:-}"
NO_PAUSE="${NO_PAUSE:-}"

ENV_FILE_FOUND="0"
SERVER_URL_DISPLAY=""
if [[ -f "${SCRIPT_DIR}/.env" ]]; then
  ENV_FILE_FOUND="1"
  while IFS='=' read -r k v; do
    [[ -z "${k}" ]] && continue
    case "${k}" in
      SERVER_URL) [[ -z "${SERVER_URL_DISPLAY}" ]] && SERVER_URL_DISPLAY="${v}" ;;
      AUTO_UPDATE) [[ -z "${AUTO_UPDATE}" ]] && AUTO_UPDATE="${v}" ;;
      AGENT_IMAGE) [[ -z "${AGENT_IMAGE}" ]] && AGENT_IMAGE="${v}" ;;
      MODELS_DIR) [[ -z "${MODELS_DIR}" ]] && MODELS_DIR="${v}" ;;
    esac
  done < "${SCRIPT_DIR}/.env"
fi

if [[ "${RESET_CONFIG}" == "1" ]]; then
  rm -f "${CONFIG_FILE}" >/dev/null 2>&1 || true
  NODE_NAME=""
fi

if [[ -f "${CONFIG_FILE}" ]]; then
  while IFS='=' read -r k v; do
    [[ -z "${k}" ]] && continue
    case "${k}" in
      WALLET_ADDRESS) [[ -z "${WALLET_ADDRESS}" ]] && WALLET_ADDRESS="${v}" ;;
      GPU_INDEX) [[ -z "${GPU_INDEX}" ]] && GPU_INDEX="${v}" ;;
      NODE_NAME) [[ -z "${NODE_NAME}" ]] && NODE_NAME="${v}" ;;
      MODELS_DIR) [[ -z "${MODELS_DIR}" ]] && MODELS_DIR="${v}" ;;
    esac
  done < "${CONFIG_FILE}"
fi

if [[ -z "${AUTO_UPDATE}" ]]; then
  AUTO_UPDATE="1"
fi
if [[ -z "${AGENT_IMAGE}" ]]; then
  AGENT_IMAGE="ghcr.io/is-pan/rabah-node:latest"
fi
if [[ -z "${MODELS_DIR}" ]]; then
  MODELS_DIR="${SCRIPT_DIR}/models"
fi
if [[ "${MODELS_DIR}" != /* ]]; then
  MODELS_DIR="${SCRIPT_DIR}/${MODELS_DIR}"
fi

docker --version >/dev/null 2>&1 || {
  echo "ERROR: Docker not found in PATH." >&2
  exit 1
}

docker info >/dev/null 2>&1 || {
  echo "ERROR: Docker is not running." >&2
  exit 1
}

ASK_WALLET="0"
ASK_GPU="0"
if [[ "${ASK_ON_START}" == "1" ]]; then
  ASK_WALLET="1"
  ASK_GPU="1"
fi
if [[ -z "${WALLET_ADDRESS}" ]]; then
  ASK_WALLET="1"
fi
if [[ -z "${GPU_INDEX}" ]]; then
  ASK_GPU="1"
fi

if [[ "${ASK_WALLET}" == "1" ]]; then
  echo "First time setup:"
  echo "- Please enter your wallet address (same as the one bound in the web Settings page)."
  if [[ -n "${WALLET_ADDRESS}" ]]; then
    echo "Current wallet: ${WALLET_ADDRESS}"
  fi
  read -r -p "Wallet Address: " WALLET_ADDRESS
  if [[ -z "${WALLET_ADDRESS}" ]]; then
    echo "ERROR: Wallet Address is required." >&2
    exit 1
  fi
fi

if [[ "${ASK_GPU}" == "1" ]]; then
  echo
  echo "GPU selection:"
  echo "- Enter GPU index (default 0). If you have only one GPU, use 0."
  if [[ -n "${GPU_INDEX}" ]]; then
    echo "Current GPU_INDEX: ${GPU_INDEX}"
  fi
  read -r -p "GPU_INDEX [0]: " GPU_INDEX_INPUT
  GPU_INDEX="${GPU_INDEX_INPUT:-0}"
fi

if [[ -z "${GPU_INDEX}" ]]; then
  GPU_INDEX="0"
fi

if [[ -z "${NODE_NAME}" || "${NODE_NAME}" == "rabah-node" ]]; then
  NODE_NAME="rabah-node-gpu${GPU_INDEX}"
fi

if [[ -z "${WALLET_ADDRESS}" ]]; then
  echo "ERROR: WALLET_ADDRESS is required." >&2
  echo "Usage: WALLET_ADDRESS=0x... ./start.sh" >&2
  exit 1
fi

if [[ "${DRY_RUN}" != "1" ]]; then
  {
    echo "WALLET_ADDRESS=${WALLET_ADDRESS}"
    echo "GPU_INDEX=${GPU_INDEX}"
    echo "NODE_NAME=${NODE_NAME}"
    echo "MODELS_DIR=${MODELS_DIR}"
  } > "${CONFIG_FILE}"
fi

mkdir -p "${MODELS_DIR}" outputs custom_nodes workflows

echo
echo "Starting node agent..."
if [[ -z "${SERVER_URL_DISPLAY}" ]]; then
  if [[ "${ENV_FILE_FOUND}" == "1" ]]; then
    echo "- SERVER_URL: default (not set in .env)"
  else
    echo "- SERVER_URL: default (built-in)"
  fi
else
  echo "- SERVER_URL: ${SERVER_URL_DISPLAY}"
fi
echo "- WALLET_ADDRESS: ${WALLET_ADDRESS}"
echo "- GPU_INDEX: ${GPU_INDEX}"
echo "- NODE_NAME: ${NODE_NAME}"
echo

AGENT_IMAGE_LC="${AGENT_IMAGE,,}"
if [[ "${AUTO_UPDATE}" == "1" ]]; then
  if [[ "${AGENT_IMAGE_LC}" == "rabah-agent:local" ]]; then
    if command -v git >/dev/null 2>&1; then
      if [[ -d "${SCRIPT_DIR}/.git" ]]; then
        echo "Updating agent source via git pull..."
        git -C "${SCRIPT_DIR}" pull --rebase --autostash || true
      fi
    fi
  else
    echo "Pulling latest image: ${AGENT_IMAGE}"
    docker pull "${AGENT_IMAGE}"
  fi
fi

docker rm -f "${NODE_NAME}" >/dev/null 2>&1 || true

ENV_FILE_ARG=()
if [[ -f "${SCRIPT_DIR}/.env" ]]; then
  ENV_FILE_ARG=(--env-file "${SCRIPT_DIR}/.env")
fi

DOCKER_CMD=()
if [[ "${AGENT_IMAGE_LC}" == "rabah-agent:local" ]]; then
  if ! docker image inspect rabah-agent:local >/dev/null 2>&1; then
    echo "Building local image: rabah-agent:local"
    if ! docker build -t rabah-agent:local "${SCRIPT_DIR}"; then
      echo
      echo "ERROR: Failed to build image rabah-agent:local" >&2
      exit 1
    fi
  fi
  DOCKER_CMD=(docker run --rm --name "${NODE_NAME}" --gpus all "${ENV_FILE_ARG[@]}" -w /workspace \
    -e "WALLET_ADDRESS=${WALLET_ADDRESS}" -e "GPU_INDEX=${GPU_INDEX}" -e "NODE_NAME=${NODE_NAME}" \
    -e "CUDA_DEVICE_ORDER=PCI_BUS_ID" -e "CUDA_VISIBLE_DEVICES=${GPU_INDEX}" -e "NVIDIA_VISIBLE_DEVICES=${GPU_INDEX}" \
    -e "PYTHONUNBUFFERED=1" -e "PYTHONPATH=/workspace:/app" \
    -e "COMFYUI_WORKFLOWS_DIR=/workspace/workflows" \
    -v "${SCRIPT_DIR}:/workspace" \
    -v "${MODELS_DIR}:/app/models" \
    -v "${MODELS_DIR}:/app/ComfyUI/models" \
    -v "${SCRIPT_DIR}/outputs:/app/outputs" \
    -v "${SCRIPT_DIR}/custom_nodes:/app/ComfyUI/custom_nodes" \
    rabah-agent:local python -u /workspace/comfy_agent.py)
else
  DOCKER_CMD=(docker run --rm --name "${NODE_NAME}" --gpus all "${ENV_FILE_ARG[@]}" \
    -e "WALLET_ADDRESS=${WALLET_ADDRESS}" -e "GPU_INDEX=${GPU_INDEX}" -e "NODE_NAME=${NODE_NAME}" \
    -e "CUDA_DEVICE_ORDER=PCI_BUS_ID" -e "CUDA_VISIBLE_DEVICES=${GPU_INDEX}" -e "NVIDIA_VISIBLE_DEVICES=${GPU_INDEX}" \
    -e "PYTHONUNBUFFERED=1" \
    -v "${MODELS_DIR}:/app/models" \
    -v "${MODELS_DIR}:/app/ComfyUI/models" \
    -v "${SCRIPT_DIR}/outputs:/app/outputs" \
    -v "${SCRIPT_DIR}/custom_nodes:/app/ComfyUI/custom_nodes" \
    "${AGENT_IMAGE}")
fi

if [[ "${DRY_RUN}" == "1" ]]; then
  echo "DRY_RUN=1"
  printf '%q ' "${DOCKER_CMD[@]}"
  echo
  exit 0
fi

set +e
"${DOCKER_CMD[@]}"
EXIT_CODE="$?"
set -e

if [[ "${EXIT_CODE}" != "0" ]]; then
  echo
  echo "Node exited with code ${EXIT_CODE}."
  echo "If the window closes too fast, run it from terminal to see logs:"
  echo "  cd \"${SCRIPT_DIR}\""
  echo "  ./start.sh"
  echo
  exit "${EXIT_CODE}"
fi
