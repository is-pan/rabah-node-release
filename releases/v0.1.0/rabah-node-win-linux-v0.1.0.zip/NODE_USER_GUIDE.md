# 节点用户使用说明（Windows / Linux）

本文档面向“节点操作员”。目标：下载解压后即可运行节点：

- Windows：双击 `start.bat`
- Linux：运行 `./start.sh`

## 1. 运行前准备

必须具备：

- NVIDIA 显卡驱动已安装（能正常识别 GPU）
- Docker 已安装并运行
  - Windows：Docker Desktop（Linux containers 模式）
  - Linux：Docker Engine + NVIDIA Container Toolkit（保证容器可用 GPU）

## 2. 文件结构（解压后应该长什么样）

最少包含：

- `start.bat`
- `stop.bat`
- `start.sh`
- `stop.sh`
- `.env`（可选）

运行中会自动生成/创建：

- `node-config.txt`（保存 WALLET_ADDRESS、GPU_INDEX、NODE_NAME、MODELS_DIR）
- `models/`（默认模型缓存目录，首次可能会自动下载很久；可通过 MODELS_DIR 自定义）
- `outputs/`（默认不会保存图片；仅在开启本地保存时使用）
- `custom_nodes/`（自定义节点目录，默认空）

## 3. 配置 `.env`（可选）

如果你直接运行官方默认配置，可以不提供 `.env`，节点会使用镜像内置默认值。

如果你需要改服务器地址或覆盖默认行为，用记事本打开 `.env`，至少确认：

```env
SERVER_URL=http://你的服务器IP或域名:3000
```

可选项（常用）：

```env
SERVER_PUBLIC_URL=http://你的公网访问地址:3000
PREFETCH_MODEL=1
UPLOAD_RESULT=1
SAVE_OUTPUT_LOCAL=0
MODELS_DIR=models
RUN_BENCHMARK=1
AUTO_UPDATE=1
AGENT_IMAGE=ghcr.io/is-pan/rabah-node:latest
```

说明：

- `SERVER_URL`：节点向服务器注册/领取任务/回传结果用的地址
- `SERVER_PUBLIC_URL`：生成 `result_url` 用的公开访问地址（没有 CDN 时通常与 `SERVER_URL` 相同）
- `PREFETCH_MODEL=1`：缺少模型时自动下载；设为 `0` 则缺模型会直接报错退出
- `UPLOAD_RESULT=1`：把图片内容也回传服务器；设为 `0` 则只回传图片 URL
- `SAVE_OUTPUT_LOCAL=1`：把任务图片保存到本机 `outputs/`；默认不保存（更隐私）
- `MODELS_DIR=...`：模型下载/缓存目录（支持绝对路径或相对脚本目录的相对路径）
- `RUN_BENCHMARK=1`：节点启动后先跑一次基准测试并上报到网页；设为 `0` 禁用
- `AUTO_UPDATE=1`：每次启动前自动更新镜像（`docker pull`）
- `AGENT_IMAGE=...`：指定节点运行的 Docker 镜像（通常保持默认）

## 3.1 自定义模型目录（MODELS_DIR）

默认情况下，模型会下载/缓存到脚本目录下的 `models/`。

你可以在 `node-config.txt`（或 `.env` / 环境变量）里设置 `MODELS_DIR` 来修改模型目录：

- 相对路径：相对于脚本目录（推荐写法：`MODELS_DIR=models`）
- 绝对路径：例如 `D:\rabah-models` 或 `/data/rabah-models`

解析优先级：

- Windows：环境变量 / `.env` → `node-config.txt` → 默认（脚本目录下 `models/`）
- Linux：环境变量 / `.env` → `node-config.txt` → 默认（脚本目录下 `models/`）

## 4. 第一次启动（双击 start.bat）

双击 `start.bat` 后，第一次通常会提示：

- 输入 `Wallet Address`（钱包地址，需要和网页绑定一致）
- 输入 `GPU_INDEX`（GPU 编号）
  - 只有一张卡一般填 `0`
  - 多卡按实际选择：`0/1/2/...`

这些会写入 `node-config.txt`，下次启动不会再问（除非你删除该文件或设置 `RESET_CONFIG=1`）。

## 4.1 多显卡运行（Windows）

建议“一张卡启动一个节点”。每个节点使用不同的 `GPU_INDEX` 和不同的 `NODE_NAME`（否则容器名会冲突）。

示例：两张显卡（GPU 0 和 GPU 1），分别开两个终端窗口执行：

窗口 1：

```powershell
cd E:\project\rabah\agent
$env:GPU_INDEX="0"
$env:NODE_NAME="rabah-node-gpu0"
.\start.bat
```

窗口 2：

```powershell
cd E:\project\rabah\agent
$env:GPU_INDEX="1"
$env:NODE_NAME="rabah-node-gpu1"
.\start.bat
```

如果你使用的是 `cmd.exe`（不是 PowerShell），则写法是：

```bat
cd /d E:\project\rabah\agent
set GPU_INDEX=1
set NODE_NAME=rabah-node-gpu1
start.bat
```

说明：

- 如果两张卡都要用同一个钱包地址，保持一致即可
- 如果希望每张卡独立钱包，可在不同窗口分别输入不同的 `Wallet Address`（会写入对应 `node-config.txt`，建议用不同目录分别运行）

## 5. 自动更新是怎么发生的

当 `.env` 里：

- `AUTO_UPDATE=1`
- `AGENT_IMAGE=ghcr.io/...:latest`

每次运行 `start.bat` 会先执行：

- `docker pull ghcr.io/...:latest`

成功后再启动节点容器。你无需手动下载新 zip。

## 6. 基准测试（Benchmark）

节点启动后会先执行一次基准测试，用于在网页端显示该节点的基准分数：

- 先 warmup 1 次（不计分，用来消除冷启动影响）
- 再跑 3 次并取平均值上报
- 不会计入“完成任务数”（它不是从服务器领取的任务）

如需关闭：在 `.env` 或启动时设置 `RUN_BENCHMARK=0`。

## 7. 常见问题排查

### 7.1 `Docker not found in PATH`

未安装 Docker 或未加入 PATH。

- Windows：安装 Docker Desktop 后重开终端/重启电脑
- Linux：安装 Docker Engine 后重新登录或重启

### 7.2 `Docker is not running`

Docker 服务未启动或不可用。

- Windows：打开 Docker Desktop 等它就绪后重试
- Linux：启动 Docker 服务后重试（例如 `systemctl start docker`）

### 7.3 `docker pull` 失败

常见原因：

- 网络无法访问 GHCR
- 镜像是 private（需要登录 GHCR 才能拉）

解决建议：

- 确认你能在命令行执行 `docker pull ghcr.io/is-pan/rabah-node:latest`
- 若包是私有，必须先 `docker login ghcr.io`（不推荐面向普通用户）

### 7.4 报错 `no CUDA-capable device` / 任务跑很慢

GPU 没被容器识别，或驱动/容器 GPU 支持没配好。确认：

- NVIDIA 驱动正常
- Docker 容器能访问 GPU（Windows：Docker Desktop GPU 支持；Linux：NVIDIA Container Toolkit）
- 机器确实有可用 GPU

### 7.5 Poll failed / Connection refused

表示节点拉任务时短暂连不上服务器（服务器重启/网络抖动）。一般重试后恢复，不影响长期运行。

## 8. 如何停止节点

- Windows：双击 `stop.bat`，会列出正在运行的节点容器并可选择停止；也可选择停止全部
- Linux：运行 `./stop.sh`，会列出正在运行的节点容器并可选择停止；也可选择停止全部

停止全部（Windows cmd.exe）：

```bat
set STOP_ALL=1
stop.bat
```

停止全部（Windows PowerShell）：

```powershell
$env:STOP_ALL="1"
.\stop.bat
```

停止全部（Linux）：

```bash
STOP_ALL=1 ./stop.sh
```

## 9. 高级：重置本机配置

如果要重新输入钱包/GPU：

- 方式 1：删除 `node-config.txt`
- 方式 2：运行前设置环境变量 `RESET_CONFIG=1` 再启动脚本

## 10. Linux 支持

节点程序运行在 Docker 容器里，所以 Linux 机器也支持运行（前提同样是 Docker + NVIDIA GPU 环境）。

Linux 下使用 `start.sh`（逻辑与 Windows 的 `start.bat` 对齐），支持交互输入并生成 `node-config.txt`。

```bash
cd /path/to/agent
chmod +x start.sh stop.sh
./start.sh
```
停止节点：见第 8 节（`./stop.sh` 或 `STOP_ALL=1 ./stop.sh`）。

### 10.1 多显卡运行（Linux）

同样建议“一张卡启动一个节点”，每个节点使用不同的 `GPU_INDEX` 和不同的 `--name/NODE_NAME`。

示例：两张显卡（GPU 0 和 GPU 1）：

终端 1：

```bash
cd /path/to/agent
WALLET_ADDRESS=你的钱包地址 GPU_INDEX=0 NODE_NAME=rabah-node-gpu0 ./start.sh
```

终端 2：

```bash
cd /path/to/agent
WALLET_ADDRESS=你的钱包地址 GPU_INDEX=1 NODE_NAME=rabah-node-gpu1 ./start.sh
```
